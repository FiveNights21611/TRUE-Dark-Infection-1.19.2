package net.mcreator.darkinfection.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.Mth;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

import net.mcreator.darkinfection.network.DarkInfectionModVariables;
import net.mcreator.darkinfection.init.DarkInfectionModBlocks;

import java.util.Random;

public class DoInfectionProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double i = 0;
		if (Mth.nextInt(new Random(), 1, 10) == 1) {
			i = 0;
			for (int index0 = 0; index0 < (int) (5); index0++) {
				i = i + 1;
				if (DarkInfectionModVariables.InfectableBlocks.get((int) i) == (world.getBlockState(new BlockPos(x + 1, y, z))).getBlock()) {
					world.setBlock(new BlockPos(x + 1, y, z), DarkInfectionModVariables.InfectedBlocks.get((int) i).defaultBlockState(), 3);
				}
				if (DarkInfectionModVariables.InfectableBlocks.get((int) i) == (world.getBlockState(new BlockPos(x - 1, y, z))).getBlock()) {
					world.setBlock(new BlockPos(x - 1, y, z), DarkInfectionModVariables.InfectedBlocks.get((int) i).defaultBlockState(), 3);
				}
				if (DarkInfectionModVariables.InfectableBlocks.get((int) i) == (world.getBlockState(new BlockPos(x, y + 1, z))).getBlock()) {
					world.setBlock(new BlockPos(x, y + 1, z), DarkInfectionModVariables.InfectedBlocks.get((int) i).defaultBlockState(), 3);
				}
				if (DarkInfectionModVariables.InfectableBlocks.get((int) i) == (world.getBlockState(new BlockPos(x, y - 1, z))).getBlock()) {
					world.setBlock(new BlockPos(x, y - 1, z), DarkInfectionModVariables.InfectedBlocks.get((int) i).defaultBlockState(), 3);
				}
				if (DarkInfectionModVariables.InfectableBlocks.get((int) i) == (world.getBlockState(new BlockPos(x, y, z + 1))).getBlock()) {
					world.setBlock(new BlockPos(x, y, z + 1), DarkInfectionModVariables.InfectedBlocks.get((int) i).defaultBlockState(), 3);
				}
				if (DarkInfectionModVariables.InfectableBlocks.get((int) i) == (world.getBlockState(new BlockPos(x, y, z - 1))).getBlock()) {
					world.setBlock(new BlockPos(x, y, z - 1), DarkInfectionModVariables.InfectedBlocks.get((int) i).defaultBlockState(), 3);
				}
			}
		}
	}
}
