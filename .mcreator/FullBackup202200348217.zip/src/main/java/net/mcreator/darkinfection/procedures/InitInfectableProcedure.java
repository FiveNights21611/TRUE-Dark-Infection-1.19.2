package net.mcreator.darkinfection.procedures;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;

import net.minecraft.world.level.block.Blocks;

import net.mcreator.darkinfection.network.DarkInfectionModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class InitInfectableProcedure {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		execute();
	}

	public static void execute() {
		execute(null);
	}

	private static void execute(@Nullable Event event) {
		DarkInfectionModVariables.InfectableBlocks.clear();
		DarkInfectionModVariables.InfectableBlocks.add(Blocks.GRASS_BLOCK);
		DarkInfectionModVariables.InfectableBlocks.add(Blocks.DIRT);
		DarkInfectionModVariables.InfectableBlocks.add(Blocks.STONE);
		DarkInfectionModVariables.InfectableBlocks.add(Blocks.DEEPSLATE);
		DarkInfectionModVariables.InfectableBlocks.add(Blocks.COBBLESTONE);
		DarkInfectionModVariables.InfectableBlocks.add(Blocks.COBBLED_DEEPSLATE);
	}
}
