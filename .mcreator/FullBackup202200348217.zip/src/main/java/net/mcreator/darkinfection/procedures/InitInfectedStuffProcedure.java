package net.mcreator.darkinfection.procedures;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;

import net.mcreator.darkinfection.network.DarkInfectionModVariables;
import net.mcreator.darkinfection.init.DarkInfectionModBlocks;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class InitInfectedStuffProcedure {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		execute();
	}

	public static void execute() {
		execute(null);
	}

private static void execute(
@Nullable Event event
) {
DarkInfectionModVariables.InfectableBlocks.clear();DarkInfectionModVariables.InfectableBlocks.add(DarkInfectionModBlocks.INFECTEDSOIL);
DarkInfectionModVariables.InfectableBlocks.clear();DarkInfectionModVariables.InfectableBlocks.add(DarkInfectionModBlocks.DARKDIRT);
DarkInfectionModVariables.InfectableBlocks.clear();DarkInfectionModVariables.InfectableBlocks.add(DarkInfectionModBlocks.VOIDSTONE);
DarkInfectionModVariables.InfectableBlocks.clear();DarkInfectionModVariables.InfectableBlocks.add(DarkInfectionModBlocks.VOIDSTONE);
DarkInfectionModVariables.InfectableBlocks.clear();DarkInfectionModVariables.InfectableBlocks.add(DarkInfectionModBlocks.VOID_COBBLE);
DarkInfectionModVariables.InfectableBlocks.clear();DarkInfectionModVariables.InfectableBlocks.add(DarkInfectionModBlocks.VOID_COBBLE);
}
}
